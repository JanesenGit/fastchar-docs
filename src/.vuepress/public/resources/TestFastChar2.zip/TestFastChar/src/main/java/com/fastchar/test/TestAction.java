package com.fastchar.test;

import com.fastchar.core.FastAction;

import java.util.LinkedHashMap;
import java.util.Map;

public class TestAction extends FastAction {
    @Override
    protected String getRoute() {
        return "/test";
    }


    public void upload() throws Exception {
        Map<String, String> data = new LinkedHashMap<>();
        data.put("user", getParam("user", true));
        data.put("image", getParamFile("image").getUrl());

        responseText("上传的数据：" + data);
    }

}
