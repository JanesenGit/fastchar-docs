package com.fastchar.test;

import com.fastchar.core.FastAction;

/**
 * 处理首页地址
 */
public class IndexAction extends FastAction {
    @Override
    protected String getRoute() {
        return "/";
    }


    public void index() {
        redirect("index.html");
    }


}
