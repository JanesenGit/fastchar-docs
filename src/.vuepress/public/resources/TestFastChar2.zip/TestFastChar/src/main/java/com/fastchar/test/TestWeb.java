package com.fastchar.test;

import com.fastchar.core.FastChar;
import com.fastchar.core.FastEngine;
import com.fastchar.interfaces.IFastWeb;

public class TestWeb implements IFastWeb {


    @Override
    public void onInit(FastEngine engine) throws Exception {
        IFastWeb.super.onInit(engine);
        FastChar.getLogger().info("初始化web项目！");
    }

    @Override
    public void onFinish(FastEngine engine) throws Exception {
        IFastWeb.super.onFinish(engine);
        //打印框架的关键信息
        engine.logFastCharInfo();
        FastChar.getLogger().info("初始化web完成！");
    }
}
