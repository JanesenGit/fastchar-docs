import com.fastchar.core.FastChar;
import com.fastchar.server.undertow.FastServerUndertow;
import com.fastchar.server.undertow.FastUndertowConfig;
import com.fastchar.utils.FastFileUtils;

import java.io.File;
import java.io.IOException;

/**
 * 项目运行器
 */
public class Application {

    public static void main(String[] args) throws IOException {
        boolean debug = args.length == 0 || args[0].equalsIgnoreCase("debug");

        if (debug) {
            String projectPath = System.getProperty("user.dir");

            //删除idea编译后生成的main文件夹，此文件夹无任何作用，但是会重复resources里的内容，会影响web资源的加载，如果使用maven编译打包则不会生成此文件夹
            //由于开发环境的区别，如果idea没有生成此文件夹，可忽略此操作
            FastFileUtils.deleteDirectory(new File(projectPath, "TestFastChar/target/classes/main"));
        }


        FastServerUndertow.getInstance()
                .start(new FastUndertowConfig()
                        .setPort(8888)
                        .setContextPath("/test_project"));
    }
}
